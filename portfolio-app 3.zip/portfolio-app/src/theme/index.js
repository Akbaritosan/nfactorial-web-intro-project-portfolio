import { extendTheme } from "@chakra-ui/react";
import typography from "./typography";

export const theme = extendTheme({ ...typography });
