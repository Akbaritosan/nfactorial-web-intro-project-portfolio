import { Flex, Text } from "@chakra-ui/react";

export function Footer() {
  return (
    <Flex py="40px" justifyContent="space-between" w="100%" px="80px">
      <Text fontFamily="body" fontWeight="medium" fontStyle="sm" color="white">
        Made with ❤️ at nFactorial in 2022.
      </Text>
      <Text
        fontFamily="body"
        fontWeight="medium"
        fontStyle="sm"
        opacity="0.5"
        color="white"
      >
        Credits: photos from Unsplash.com, icons from Icons8.
      </Text>
    </Flex>
  );
}
