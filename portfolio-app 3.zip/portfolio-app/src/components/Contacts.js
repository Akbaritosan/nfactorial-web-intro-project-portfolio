import { Button, Flex, Text } from "@chakra-ui/react";
import { PartTemplate } from "../templates/PartTemplate";

export function Contacts({ innerRef }) {
  return (
    <PartTemplate>
      <Flex flexDir="column" justifyContent="center" mt="64px" ref={innerRef}>
        <Text
          color="white"
          fontSize="6xl"
          lineHeight="6xl"
          fontFamily="mono"
          fontWeight="bold"
        >
          Say Hello
        </Text>
        <Text
          color="white"
          fontWeight="light"
          fontSize="xl"
          lineHeight="xl"
          fontFamily="heading"
          mt="32px"
          mb="40px"
        >
          I’m a web development student and this is my portfolio.
        </Text>
        <a href="https://www.linkedin.com/in/akbar-sandybay-101673216/details/experience/" target="_blank" rel="noopener noreferrer">
        <Button
          w="200px"
          bgColor="#FD5A14"
          p="16px 24px"
          borderRadius="2px"
          fontFamily="body"
          color="white"
          _hover={{ bgColor: "#FD5A14" }}
        >
          Get in touch
        </Button>
        </a>
      </Flex>
    </PartTemplate>
  );
}
