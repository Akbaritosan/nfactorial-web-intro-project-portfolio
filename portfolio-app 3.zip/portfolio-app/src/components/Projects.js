import Media from "../assets/images/media.png";
import Todolist from "../assets/images/todolist.png";
import Jumystap from "../assets/images/jumystap.png";
import { PageHeading } from "./PageHeading";
import { Box, Flex } from "@chakra-ui/react";
import { ProjectItem } from "./ProjectItem";
import { PartTemplate } from "../templates/PartTemplate";

export function Projects({ innerRef }) {
  const data = [
    {
      id: 0,
      title: "Simple To do list",
      description:
        "I’m learning web programming and this is one of my projects.\n" +
        "In this Project we recreated a website like Notion",
      tech: ["This project contains main page and a creation of a new list"],
      image: Todolist,
    },
    {
      id: 1,
      title: "Media as Medium",
      description:
        "I’m learning web programming and this is one of my projects.\n" +
        "In this Project we recreated a website like Medium",
      tech: ["This project contains main page with articles and pages of an article"],
      image: Media,
    },
    {
      id: 2,
      title: "Jumystap",
      description:
        "I’m learning web programming and this is one of my projects.\n" +
        "In this Project we created a landing Page for Job Fnding systems",
      tech: ["This project is a single page with the basic information"],
      image: Jumystap,
    },
  ];

  return (
    <PartTemplate>
      <Box py="64px" w="100%" ref={innerRef}>
        <PageHeading title="Projects I’ve Worked On" />
        <Flex flexDir="column" gap="128px" mt="64px" w="100%">
          {data.map((item) => (
            <ProjectItem key={item.id} isReversed={item.id % 2} {...item} />
          ))}
        </Flex>
      </Box>
    </PartTemplate>
  );
}
