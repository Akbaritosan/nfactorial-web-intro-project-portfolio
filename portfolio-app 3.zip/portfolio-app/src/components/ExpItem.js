import { Box, Center, Circle, Flex, Text } from "@chakra-ui/react";

export function ExpItem(props) {
  const { title, geo, description, date } = props;

  return (
    <Flex gap="20px">
      <Text
        color="white"
        fontWeight="bold"
        fontStyle="xs"
        fontFamily="mono"
        w="143px"
      >
        {date}
      </Text>
      <Box>
        <Box>
          <Center gap="12px" justifyContent="flex-start">
            <Circle size="22px" bgColor="#EA6531" />
            <Text
              color="white"
              fontWeight="medium"
              fontStyle="md"
              fontFamily="body"
            >
              {title}
            </Text>
          </Center>
          <Text
            ml="34px"
            color="white"
            fontWeight="normal"
            fontStyle="xs"
            fontFamily="body"
          >
            {geo}
          </Text>
        </Box>
        <Text
          color="white"
          fontWeight="normal"
          fontStyle="sm"
          fontFamily="body"
          maxW="467px"
        >
          {description}
        </Text>
      </Box>
    </Flex>
  );
}
