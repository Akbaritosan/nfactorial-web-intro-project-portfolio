import { Center, Flex, Heading, Link, Text } from "@chakra-ui/react";

export function Header({ aboutRef, expRef, projectsRef, contactsRef }) {
  const handleClickScroll = (ref) => {
    if (ref) ref.current.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <Center justifyContent="space-between" py="30px" w="100%" px="80px">
      <Text color="white" textStyle="2xl" fontFamily="mono">
        Sandybay Akbar
      </Text>
      <Heading />
      <Flex gap="32px">
        <Link
          color="white"
          onClick={() => handleClickScroll(aboutRef)}
          textStyle="sm"
          fontFamily="mono"
        >
          About
        </Link>
        <Link
          color="white"
          textStyle="sm"
          fontFamily="mono"
          onClick={() => handleClickScroll(expRef)}
        >
          Experience
        </Link>
        <Link
          color="white"
          textStyle="sm"
          fontFamily="mono"
          onClick={() => handleClickScroll(projectsRef)}
        >
          Projects
        </Link>
        <Link
          color="white"
          textStyle="sm"
          fontFamily="mono"
          onClick={() => handleClickScroll(contactsRef)}
        >
          Contact
        </Link>
      </Flex>
    </Center>
  );
}
