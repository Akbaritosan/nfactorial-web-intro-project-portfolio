import { Box, Center, Circle, Flex, Image, Text } from "@chakra-ui/react";

export function ProjectItem({ title, description, tech, image, isReversed }) {
  return (
    <Flex
      w="100%"
      justifyContent="space-between"
      alignItems="center"
      flexDirection={isReversed ? "row-reverse" : "row"}
    >
      <Box>
        <Text
          color="white"
          fontSize="40px"
          fontFamily="mono"
          fontWeight="bold"
          lineHeight="54px"
        >
          {title}
        </Text>
        <Text
          color="white"
          fontWeight="light"
          fontSize="xl"
          lineHeight="xl"
          fontFamily="heading"
          mt="32px"
          mb="40px"
          maxW="468px"
        >
          {description}
        </Text>
        <Center justifyContent="flex-start" gap="32px">
          {tech.map((skill, index) => (
            <Box key={index}>
              <Center gap="12px">
                <Circle size="22px" bgColor="#40354F" />
                <Text
                  color="white"
                  fontWeight="medium"
                  fontStyle="md"
                  fontFamily="body"
                >
                  {skill}
                </Text>
              </Center>
            </Box>
          ))}
        </Center>
      </Box>
      <Image src={image} h="388px" w="626px" />
    </Flex>
  );
}
