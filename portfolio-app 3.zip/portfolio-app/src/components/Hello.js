import { Button, Flex, Text } from "@chakra-ui/react";

export function Hello() {
  return (
    <Flex
      flexDir="column"
      h="80vh"
      justifyContent="center"
      borderY="1px solid rgba(255, 255, 255, 0.2)"
      px="80px"
    >
      <Text
        color="white"
        fontSize="6xl"
        lineHeight="6xl"
        fontFamily="mono"
        fontWeight="bold"
      >
        Hi, I’m Sandybay Akbar,
        <br />I build things for the web.
      </Text>
      <Text
        color="white"
        fontWeight="light"
        fontSize="xl"
        lineHeight="xl"
        fontFamily="heading"
        mt="32px"
        mb="40px"
      >
        I’m a web development student and this is my portfolio.
      </Text>
      <a href="https://www.linkedin.com/in/akbar-sandybay-101673216/details/experience/" target="_blank" rel="noopener noreferrer">
      <Button
        w="200px"
        bgColor="#FD5A14"
        p="16px 24px"
        borderRadius="2px"
        fontFamily="body"
        color="white"
        _hover={{ bgColor: "#FD5A14" }}
      >
        Check out my CV
      </Button>
      </a>
    </Flex>
  );
}
