import { Box, Center, Circle, Flex, Image, Text } from "@chakra-ui/react";
// import AboutMeImage from "../assets/images/aboutme.png";
import AboutMeImage from "../assets/images/ava.JPG";
import { PageHeading } from "./PageHeading";
import { PartTemplate } from "../templates/PartTemplate";

export function About({ innerRef }) {
  return (
    <PartTemplate>
      <Flex w="100%" justifyContent="space-between" ref={innerRef}>
        <Box>
          <PageHeading title="About me" />
          <Text
            color="white"
            fontWeight="light"
            fontSize="xl"
            lineHeight="xl"
            fontFamily="heading"
            mt="32px"
            mb="40px"
            maxW="629px"
          >
            I’m a KBTU graduate, junior product manager and web development student and this is my portfolio and work experience.
          </Text>
          <Center justifyContent="flex-start" gap="32px">
            <Box>
              <Center gap="12px">
                <Circle size="22px" bgColor="#40354F" />
                <Text
                  color="white"
                  fontWeight="medium"
                  fontStyle="md"
                  fontFamily="body"
                >
                  Jumystap Web App 
                </Text>
              </Center>
            </Box>
            <Box>
              <Center gap="12px">
                <Circle size="22px" bgColor="#40354F" />
                <Text
                  color="white"
                  fontWeight="medium"
                  fontStyle="md"
                  fontFamily="body"
                >
                  Media as Medium
                </Text>
              </Center>
            </Box>
          </Center>
          <Center justifyContent="flex-start" gap="32px" mt="24px">
            <Box>
              <Center gap="12px">
                <Circle size="22px" bgColor="#40354F" />
                <Text
                  color="white"
                  fontWeight="medium"
                  fontStyle="md"
                  fontFamily="body"
                >
                  To do list
                </Text>
              </Center>
            </Box>
          </Center>
        </Box>
        <Image src={AboutMeImage} h="320px" w="280px" />
      </Flex>
    </PartTemplate>
  );
}
