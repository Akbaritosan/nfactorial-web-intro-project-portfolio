import { Box, Flex } from "@chakra-ui/react";
import { PageHeading } from "./PageHeading";
import { ExpItem } from "./ExpItem";
import { PartTemplate } from "../templates/PartTemplate";

export function Experience({ innerRef }) {
  const data = [
    {
      id: 0,
      title: "Product Manager at Yume Rental",
      geo: "Kazakhstan, Almaty",
      description: 
        "I'm working as a product manager in a video equipment rental service,\n" +
        "creating an online service for video equipment rental services",
      date: 
        "March 2023 - Nowadays",
    },
    {
      id: 1,
      title: "Data Analytics Intern at Prime Soucre",
      geo: "Kazakhstan, Almaty",
      description: 
        "I worked as a Data Analyst, working on Projects for KazakhTelecom.", 
      date: "September 2022 - March 2023",
    },
    {
      id: 2,
      title: "Data Analytics Intern at Beeline",
      geo: "Kazakhstan, Almaty",
      description: 
       "I worked as a Data Analyst, gathering data to create our own NPS system.", 
      date: 
        "August 2021 - November 2021",
    },
  ];

  return (
    <PartTemplate>
      <Box py="64px" ref={innerRef}>
        <PageHeading title="Experience" />
        <Flex mt="64px" gap="48px" flexDir="column">
          {data.map((item) => (
            <ExpItem key={item.id} {...item} />
          ))}
        </Flex>
        
      </Box>
    </PartTemplate>
  );
}
