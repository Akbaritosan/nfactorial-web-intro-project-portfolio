import { Text } from "@chakra-ui/react";

export function PageHeading({ title }) {
  return (
    <Text
      color="white"
      fontSize="6xl"
      lineHeight="6xl"
      fontFamily="mono"
      fontWeight="bold"
    >
      {title}
    </Text>
  );
}
