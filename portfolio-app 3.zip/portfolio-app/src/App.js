import "./App.css";
import { Box, ChakraProvider, extendTheme } from "@chakra-ui/react";
import { AppTemplate } from "./templates/AppTemplate";
import { Header } from "./components/Header";
import { theme } from "./theme";
import { Hello } from "./components/Hello";
import { About } from "./components/About";
import { Experience } from "./components/Experience";
import { Projects } from "./components/Projects";
import { Contacts } from "./components/Contacts";
import { Footer } from "./components/Footer";
import { useRef } from "react";

function App() {
  const aboutRef = useRef(null);
  const expRef = useRef(null);
  const projectsRef = useRef(null);
  const contactsRef = useRef(null);

  return (
    <ChakraProvider theme={theme}>
      <AppTemplate>
        <Box>
          <Header
            aboutRef={aboutRef}
            contactsRef={contactsRef}
            projectsRef={projectsRef}
            expRef={expRef}
          />
          <Hello />
          <About innerRef={aboutRef} />
          <Experience innerRef={expRef} />
          <Projects innerRef={projectsRef} />
          <Contacts innerRef={contactsRef} />
          <Footer />
        </Box>
      </AppTemplate>
    </ChakraProvider>
  );
}

export default App;
