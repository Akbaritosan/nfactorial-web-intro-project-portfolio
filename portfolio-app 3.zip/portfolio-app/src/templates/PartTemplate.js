import { Flex } from "@chakra-ui/react";

export const PartTemplate = ({ children }) => {
  return (
    <Flex
      minH="100vh"
      alignItems="center"
      borderBottom="1px solid rgba(255, 255, 255, 0.2)"
      px="80px"
      w="100%"
    >
      {children}
    </Flex>
  );
};
