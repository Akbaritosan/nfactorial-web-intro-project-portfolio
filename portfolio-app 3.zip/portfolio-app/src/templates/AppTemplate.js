import { Box } from "@chakra-ui/react";

export function AppTemplate({ children }) {
  return (
    <Box bgColor="#130125" height="100%">
      {children}
    </Box>
  );
}
